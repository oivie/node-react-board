// Auth types
export const REGISTER_SUCCESS = 'REGISTER_SUCCESS';
export const REGISTER_FAIL = 'REGISTER_FAIL';
export const USER_LOADED = 'USER_LOADED';
export const AUTH_ERROR = 'AUTH_ERROR';
export const LOGIN_SUCCESS = 'LOGIN_SUCCESS';
export const LOGIN_FAIL = 'LOGIN_FAIL';
export const LOGOUT = 'LOGOUT';

// Event types
export const GET_EVENTS = 'GET_EVENTS';
export const GET_EVENT_DETAILS = 'GET_EVENT_DETAILS';
export const CREATE_EVENT = 'CREATE_EVENT';
export const UPDATE_EVENT = 'UPDATE_EVENT';
export const DELETE_EVENT = 'DELETE_EVENT';

// RSVP types
export const RSVP_EVENT = 'RSVP_EVENT';
export const CANCEL_RSVP = 'CANCEL_RSVP';
