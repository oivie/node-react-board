import axios from 'axios';
import {
  GET_EVENTS,
  GET_EVENT_DETAILS,
  CREATE_EVENT,
  UPDATE_EVENT,
  DELETE_EVENT
} from './types';

// Get all events
export const getEvents = () => async dispatch => {
  try {
    const res = await axios.get('/api/events');
    dispatch({
      type: GET_EVENTS,
      payload: res.data
    });
  } catch (err) {
    console.error(err);
  }
};

// Get event details
export const getEventDetails = (id) => async dispatch => {
  try {
    const res = await axios.get(`/api/events/${id}`);
    dispatch({
      type: GET_EVENT_DETAILS,
      payload: res.data
    });
  } catch (err) {
    console.error(err);
  }
};

// Create a new event
export const createEvent = (eventData) => async dispatch => {
  try {
    const res = await axios.post('/api/events', eventData);
    dispatch({
      type: CREATE_EVENT,
      payload: res.data
    });
  } catch (err) {
    console.error(err);
  }
};

// Update an event
export const updateEvent = (id, eventData) => async dispatch => {
  try {
    const res = await axios.put(`/api/events/${id}`, eventData);
    dispatch({
      type: UPDATE_EVENT,
      payload: res.data
    });
  } catch (err) {
    console.error(err);
  }
};

// Delete an event
export const deleteEvent = (id) => async dispatch => {
  try {
    await axios.delete(`/api/events/${id}`);
    dispatch({
      type: DELETE_EVENT,
      payload: id
    });
  } catch (err) {
    console.error(err);
  }
};
