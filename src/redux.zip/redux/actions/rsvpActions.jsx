import axios from 'axios';
import { RSVP_EVENT, CANCEL_RSVP } from './types';

// RSVP to an event
export const rsvpEvent = (eventId) => async dispatch => {
  try {
    const res = await axios.post(`/api/rsvp/${eventId}`);
    dispatch({
      type: RSVP_EVENT,
      payload: res.data
    });
  } catch (err) {
    console.error(err);
  }
};

// Cancel RSVP
export const cancelRsvp = (eventId) => async dispatch => {
  try {
    const res = await axios.delete(`/api/rsvp/${eventId}`);
    dispatch({
      type: CANCEL_RSVP,
      payload: res.data
    });
  } catch (err) {
    console.error(err);
  }
};
