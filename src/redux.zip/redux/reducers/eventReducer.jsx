import {
    GET_EVENTS,
    GET_EVENT_DETAILS,
    CREATE_EVENT,
    UPDATE_EVENT,
    DELETE_EVENT
  } from '../actions/types';
  
  const initialState = {
    events: [],
    eventDetails: null,
    loading: true
  };
  
  export default function (state = initialState, action) {
    const { type, payload } = action;
  
    switch (type) {
      case GET_EVENTS:
        return {
          ...state,
          events: payload,
          loading: false
        };
      case GET_EVENT_DETAILS:
        return {
          ...state,
          eventDetails: payload,
          loading: false
        };
      case CREATE_EVENT:
        return {
          ...state,
          events: [...state.events, payload],
          loading: false
        };
      case UPDATE_EVENT:
        return {
          ...state,
          events: state.events.map(event =>
            event._id === payload._id ? payload : event
          ),
          loading: false
        };
      case DELETE_EVENT:
        return {
          ...state,
          events: state.events.filter(event => event._id !== payload),
          loading: false
        };
      default:
        return state;
    }
  }
  