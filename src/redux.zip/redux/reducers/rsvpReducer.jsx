import { RSVP_EVENT, CANCEL_RSVP } from '../actions/types';

const initialState = {
  rsvps: [],
  loading: true
};

export default function (state = initialState, action) {
  const { type, payload } = action;

  switch (type) {
    case RSVP_EVENT:
      return {
        ...state,
        rsvps: [...state.rsvps, payload],
        loading: false
      };
    case CANCEL_RSVP:
      return {
        ...state,
        rsvps: state.rsvps.filter(rsvp => rsvp._id !== payload._id),
        loading: false
      };
    default:
      return state;
  }
}
