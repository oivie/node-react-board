import { combineReducers } from 'redux';
import authReducer from './authReducer';
import eventReducer from './eventReducer';
import rsvpReducer from './rsvpReducer';

const rootReducer = combineReducers({
  auth: authReducer,
  events: eventReducer,
  rsvp: rsvpReducer,
});

export default rootReducer;
